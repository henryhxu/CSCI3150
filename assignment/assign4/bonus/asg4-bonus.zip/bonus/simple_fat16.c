#include <errno.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/timeb.h>

#define DEPTH_INCREMENT 10

#include "fat16.h"

/*  HELPER FUNCTIONS  */
//------------------------------------------------------------------------------
// We provide several helper functions to help your coding.
// You do not need to use all of them, just select the ones that you think can be helpful.

/* Function: split the path, while keep their original format 
 * ==================================================================================
 * exp: "/dir1/dir2/text"  -> {"dir1","dir2","text"}
 * ==================================================================================
*/
char **org_path_split(char *pathInput){
  int i, j;
  int pathDepth = 0;
  for (i = 0; pathInput[i] != '\0'; i++)
  {
    if (pathInput[i] == '/')
    {
      pathDepth++;
    }
  }
  char **orgPaths = (char **)malloc(pathDepth * sizeof(char *));
  const char token[] = "/";
  char *slice;

  /* Dividing the path into separated strings of file names */
  slice = strtok(pathInput, token);
  for (i = 0; i < pathDepth; i++)
  {
    orgPaths[i] = slice;
    slice = strtok(NULL, token);
  }
  return orgPaths;
}

/* Function:  This function receieves a FAT file/directory name (DIR_Name) and decodes it
 *            to its original user input name.
*/
BYTE *path_decode(BYTE *path)
{

  int i, j;
  BYTE *pathDecoded = malloc(MAX_SHORT_NAME_LEN * sizeof(BYTE));

  /* If the name consists of "." or "..", return them as the decoded path */
  if (path[0] == '.' && path[1] == '.' && path[2] == ' ')
  {
    pathDecoded[0] = '.';
    pathDecoded[1] = '.';
    pathDecoded[2] = '\0';
    return pathDecoded;
  }
  if (path[0] == '.' && path[1] == ' ')
  {
    pathDecoded[0] = '.';
    pathDecoded[1] = '\0';
    return pathDecoded;
  }

  /* Decoding from uppercase letters to lowercase letters, removing spaces,
   * inserting 'dots' in between them and verifying if they are legal */
  for (i = 0, j = 0; i < 11; i++)
  {
    if (path[i] != ' ')
    {
      if (i == 8)
        pathDecoded[j++] = '.';

      if (path[i] >= 'A' && path[i] <= 'Z')
        pathDecoded[j++] = path[i] - 'A' + 'a';
      else
        pathDecoded[j++] = path[i];
    }
  }
  pathDecoded[j] = '\0';
  return pathDecoded;
}

/* Function: Get parent directory path of a specified file 
 * ==================================================================================
 * exp: path = "dir1/dir2/texts" orgPaths = { "dir1", "dir2", "tests" }
 * Return "dir1/dir2"
 * ==================================================================================
*/
char * get_prt_path(const char *path, const char **orgPaths,int pathDepth){
  char *prtPath;
  if(pathDepth == 1){
    prtPath = (char *)malloc(2*sizeof(char));
    prtPath[0] = '/';
    prtPath[1] = '\0';
  }
  else {
    int prtPathLen = strlen(path) - strlen(orgPaths[pathDepth-1])-1;
    prtPath = (char *)malloc((prtPathLen+1)*sizeof(char));
    strncpy(prtPath, path, prtPathLen);
    prtPath[prtPathLen] = '\0';
  }
  return prtPath;
}

/* Function: Read the sector 'secnum' from the image to the buffer
*/
void sector_read(FILE *fd, unsigned int secnum, void *buffer)
{
  fseek(fd, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fread(buffer, BYTES_PER_SECTOR, 1, fd);
}

/**
 * Function: Given a cluster number [ClusterN], this function 
 *           1. reads its first sector into buffer, 
 *           2. set *FatClusEntryVal as the cluster entry value of the cluster [ClusterN] 
 *           3. set *FirstSectorofCluster as the sector number of the cluster's first sector
**/
void first_sector_by_cluster(FAT16 *fat16_ins, WORD ClusterN, WORD *FatClusEntryVal, WORD *FirstSectorofCluster, BYTE *buffer)
{
  *FatClusEntryVal = fat_entry_by_cluster(fat16_ins, ClusterN);
  *FirstSectorofCluster = ((ClusterN - 2) * fat16_ins->Bpb.BPB_SecPerClus) + fat16_ins->FirstDataSector;

  sector_read(fat16_ins->fd, *FirstSectorofCluster, buffer);
}

/**
 * Function: Browse directory entries in root directory.
 * ==================================================================================
 * Return
 * 0, if we did find a file corresponding to the given path 
 * or 1 if we did not
 * ==================================================================================
**/
int find_root(FAT16 *fat16_ins, DIR_ENTRY *Root, const char *path)
{
  int i, j;
  int RootDirCnt = 1, is_eq;
  BYTE buffer[BYTES_PER_SECTOR];

  int pathDepth;
  char **paths = path_split((char *)path, &pathDepth);

  sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, buffer);

  /* We search for the path in the root directory first */
  for (i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
  {
    memcpy(Root, &buffer[((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR], BYTES_PER_DIR);

    /* If the directory entry is free, all the next directory entries are also
     * free. So this file/directory could not be found */
    if (Root->DIR_Name[0] == 0x00)
    {
      return 1;
    }

    /* Comparing strings character by character */
    is_eq = strncmp(Root->DIR_Name, paths[0], 11) == 0 ? 1 : 0;

    /* If the path is only one file (ATTR_ARCHIVE) and it is located in the
     * root directory, stop searching */
    if (is_eq && Root->DIR_Attr == ATTR_ARCHIVE)
    {
      return 0;
    }

    /* If the path is only one directory (ATTR_DIRECTORY) and it is located in
     * the root directory, stop searching */
    if (is_eq && Root->DIR_Attr == ATTR_DIRECTORY && pathDepth == 1)
    {
      return 0;
    }

    /* If the first level of the path is a directory, continue searching
     * in the root's sub-directories */
    if (is_eq && Root->DIR_Attr == ATTR_DIRECTORY)
    {
      return find_subdir(fat16_ins, Root, paths, pathDepth, 1);
    }

    /* End of bytes for this sector (1 sector == 512 bytes == 16 DIR entries)
     * Read next sector */
    if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
    {
      sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, buffer);
      RootDirCnt++;
    }
  }

  /* We did not find anything */
  return 1;
}

//------------------------------------------------------------------------------

/** TODO:
 * split the path with token "/", and transform the splitted path into strings in FAT file name format
 * 
 * Input: 
 *  1. pathInput: the file path, i.e. /dir1/dir2/file.txt
 * Output: 
 *  2. pathDepth_ret: the depth of file, i.e. 3 (for /dir1/dir2/file.txt)
 * Return: the string in FAT file name format
 * 
 * Hint1: if pathInput is "/dir1/dir2/file.txt", then it will be splitted into "dir1", "dir2", "file.txt".
 *        Then we should transform each of them into a file name in FAT format, which has a length of 11 capital characters
 *        , i.e. "file.txt" -> "FILE    TXT".
 *        Then return the string "FILE    TXT", set *pathDepth_ret to 3. You can also check the FAT file format in asg4 documentation.
 * Hint2: you need to consider the situation where input string is too long. For example, if the input is "/.Trash-1000", you need to truncate the string.
 * Hint3: you need to consider the situation where input string is "/." or "/..".
 **/
char **path_split(char *pathInput, int *pathDepth_ret)
{
  int i, j;
  int pathDepth = 0;

  /* START OF CODE */






  /* END OF CODE */

  char **paths = malloc(pathDepth * sizeof(char *));

  /* START OF CODE */
  












  //return paths; 
  /* END OF CODE */
}



/**
 * Reads BPB, calculates the first sector of the root and data sections.
 * ============================================================================
 * Return
 * @fat16_ins: Structure that contains essential data about the File System (BPB,
 * first sector number of the Data Region, number of sectors in the root
 * directory and the first sector number of the Root Directory Region).
* =============================================================================
**/
FAT16 *pre_init_fat16(const char *fat_file_name)
{
  /* Opening the FAT16 image file */
  FILE *fd = fopen(fat_file_name, "r+");

  if (fd == NULL)
  {
    fprintf(stderr, "Missing FAT16 image file!\n");
    exit(EXIT_FAILURE);
  }

  FAT16 *fat16_ins = malloc(sizeof(FAT16));

  fat16_ins->fd = fd;

  /** TODO: 
   * initialize other memebers variables of fat16_ins
   * Hint: the size of root directory is related to Bpb.BPB_RootEntCnt, and is sector-aligned
  **/
  /* START OF CODE */








  /* END OF CODE */

  return fat16_ins;
}


/** TODO:
 * return the FAT entry that the cluster numbered [ClusterN] corresponds to 
**/
WORD fat_entry_by_cluster(FAT16 *fat16_ins, WORD ClusterN)
{
  /* Buffer to store bytes from the image file and the FAT16 offset */ 
  BYTE sector_buffer[BYTES_PER_SECTOR];
  /* START OF CODE */
  
  




  //return 0xffff;  //you can modify this value

  /* END OF CODE */
}


/** TODO:
 * find the file or directory specified by paths under the directory Dir
 * if found, return 0, and replace Dir with the directory entry found; else return 1.
 * 
 * Hint1: At the entry of find_subdir, Dir should be the starting directory that our search is based on. We need to read the data of the sectors in this directory's cluster(s)
 * Hint2: The size of the directory is unknown, so directory may lie across multiple sectors and clusters. When we find some entry that contains 0x0000, we can stop.
 * Hint3: We are searching for the directory or file named paths[curDepth] in this function call. And we need to use pathDepth to determine whether find_subdir needs to be recursively called 
 *        in this function call.
 * Hint4: refer to find_root, the code logic is similar
**/
int find_subdir(FAT16 *fat16_ins, DIR_ENTRY *Dir, char **paths, int pathDepth, int curDepth)
{
  int i, j, DirSecCnt = 1, is_eq;
  BYTE buffer[BYTES_PER_SECTOR];

  WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;
  
  ClusterN = Dir->DIR_FstClusLO;

  first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, buffer);

  /* Searching for the given path in all directory entries of Dir */
  /* START OF CODE */
  
  











  /* END OF CODE */

  /* We did not find the given path */
  return 1;
}


/** TODO:
 * Rountine required by FUSE. 
 * Function: read directory entries of directory path [path]
 * Hint: 
 *      1. [offset] can be ignored here (check function prototype of (*readdir) in fuse.h for more information)
 *      2. filler usage: filler(buffer, filename, NULL, 0)
           It will fill the directory entry of filename into the buffer. 
           The buffer is the the buffer passed into readdir, the filename is the filename of the entry you want to fill into buffer in its ORIGINAL format, not FAT32 file name format.  
           Other arguments can be left the same as the above example. (check function prototype of (*readdir) in fuse.h for more information) 
**/
int fat16_readdir(const char *path, void *buffer, fuse_fill_dir_t filler,
                  off_t offset, struct fuse_file_info *fi)
{
  FAT16 *fat16_ins;
  BYTE sector_buffer[BYTES_PER_SECTOR];
  int RootDirCnt = 1, DirSecCnt = 1, i;

  /* Gets volume data supplied in the context during the fat16_init function */
  struct fuse_context *context;
  context = fuse_get_context();
  fat16_ins = (FAT16 *)context->private_data;

  sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);

  if (strcmp(path, "/") == 0)
  {
    DIR_ENTRY Root;
    /** TODO:
     * Fill the files and directories under root directory into the buffer via filler helper.
     * Note: we do not need to go into sub-directories and traverse them here. This function only need to read directory entries of directory [path]
    **/
    /* Starts filling the requested directory entries into the buffer */
    for (i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {

      /* START OF CODE */

      










      /* END OF CODE */
    }
  }
  else
  {
    DIR_ENTRY Dir;
 
    /** TODO:
     * Use find_root to obtain the directory corresponding to [path],
     * then fill the files or directories under it into buffer via filler,
     * Note: we do not need to traverse sub-directories here
     * Hint: you need to consider the size of the directory, for example, this directory may lie across sector and clusters
    **/

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, path);

    /* Calculating the first cluster sector for the given path */
    WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;
    
    ClusterN = Dir.DIR_FstClusLO;

    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */

    /* START OF CODE */



















    /* END OF CODE */

  }
  return 0;
}


/** TODO:
 * Rountine required by FUSE. 
 * read [size] bytes of data starting from the [offset]-th byte in the file [path]. Return the actual number of bytes that have been read.
 * 
 * Hint: 1. Dir.DIR_FileSize attribute specifies the size of the file
 *       2. When offset exceeds the size of the file, 0 should be returned
**/
int fat16_read(const char *path, char *buffer, size_t size, off_t offset,
               struct fuse_file_info *fi)
{
  int i, j;
  BYTE *sector_buffer = malloc((size + offset) * sizeof(BYTE));

  /* Gets volume data supplied in the context during the fat16_init function */
  FAT16 *fat16_ins;
  struct fuse_context *context;
  context = fuse_get_context();
  fat16_ins = (FAT16 *)context->private_data;

  /* Searches for the given path */
  DIR_ENTRY Dir;
  find_root(fat16_ins, &Dir, path);
  /* START OF THE CODE */








  /* END OF THE CODE */
  free(sector_buffer);
  return size;
}
