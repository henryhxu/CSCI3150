// hellomain.c
#include "hellofunc.h"

int main() {
    // call a function in another file
    myPrintHello();
    return 0;
}