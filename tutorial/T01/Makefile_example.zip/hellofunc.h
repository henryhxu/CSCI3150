// hellofunc.h

void myPrintHello();