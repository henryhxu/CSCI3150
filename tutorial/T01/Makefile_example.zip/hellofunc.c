// hellofunc.c
#include <stdio.h>

void myPrintHello() {
    printf("Hello from myPrintHello()!\n");
    return;
}